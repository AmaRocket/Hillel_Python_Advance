'''
Инициализировать пустой словарь
Спросить имя пользователя и добавить его в словарь
Спросить возраст пользователя и добавить его в словарь
Спросить названия любимых фильмов пользователя, введенных через запятую, и добавить их в словарь списком
Вывести пользователю весь словарь
Вывести пользователю список ключей словаря
Спросить пользователя какой элемент заменить
Спросить пользователя на какую строку заменить элемент
Заменить указанный элемент на указанную строку
Вывести словарь
Попросить пользователя ввести ключ который может быть а может не быть в словаре
Запросить значение которое вывести если в словаре нет этого ключа
Вывести значение из словаря или пользовательское
(15 баллов)
ознакомьтесь с типом данных dict и его методами
'''
dict = {}

name = input('Enter Yo Name: ')
age = input('Enter Yo Age: ')
movies = input('Enter Yo Favourite Movies by ",": ')

dict['name'] = name
dict['age'] = age
dict['favourite movies'] = movies
print(dict)
print(list(dict.keys()))
new_val_key = input('Eneter key 4 change: ')
new_val = input('Enter value 4 change: ')
dict[new_val_key] = new_val

print(dict)
print(input('Enter key 4 search: ') in dict)
key = input('Enter key in dictionary: ')
value = input('Enter value in dictionary: ')
print(dict.get(key, value))
