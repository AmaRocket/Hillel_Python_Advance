from random import randint
'''
Есть список (в 1-й строке вашего скрипта созданный вами, я его могу заменить на любой другой во время проверки) 
из случайного кол-ва элементов (минимум 10).
Пользователь вводит начало, конец и шаг слайса - вывести слайс (5 баллов)
'''
lst = [randint(0, 10) for _ in range(10)]
print(lst)
start_of_slice = int(input('Enter Start Of Slice: '))
end_of_slice = int(input('Enter End Of Slice: '))
step_of_slice = int(input('Enter Step Of Slice: '))
print(lst[start_of_slice: end_of_slice: step_of_slice])
