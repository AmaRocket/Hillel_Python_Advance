'''
Составить выражение из True, False, not, and, or которое будет состоять как минимум из 3 "слов".
На первой строке - само выражение, на второй - это же выражение, в котором расставлены скобки так, что порядок
выполнения не меняется. Например
True and False or not False or True and False
(((True and False) or (not False)) or (True and False))
обратитесь к ссылке прикрепленной к лекции
по 1 баллу за слово, максимум 10 баллов (и слов)
'''
a = not False and not True or True and False or not False and True
print(a)
b = (((not False) and (not True)) or (True and False)) or ((not False and True))
print(b)